<?php

namespace App\Controller;
use App\Entity\Traning;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class TrainingController extends AbstractController
{
    #[Route('/trainings', name: 'app_trainings')]
    public function index(EntityManagerInterface $entityManagerInterface): Response
    {
        $trainings = $entityManagerInterface->getRepository(Traning::class)->findAll();
        return $this->render('traning/index.html.twig', array('trainings' => $trainings));
    
    }

    #[Route('/training/{id}', name: 'app_training')]
    public function Piet(EntityManagerInterface $entityManagerInterface , $id): Response
    {
        $training = $entityManagerInterface->getRepository(Traning::class)->find($id);
        return $this->render('traning/training.html.twig', array('training' => $training));
    
    }

    
}
